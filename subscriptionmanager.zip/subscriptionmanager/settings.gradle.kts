rootProject.name = "subscriptionmanager"
