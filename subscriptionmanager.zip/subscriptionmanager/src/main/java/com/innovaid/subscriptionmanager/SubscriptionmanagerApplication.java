package com.innovaid.subscriptionmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubscriptionmanagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubscriptionmanagerApplication.class, args);
	}

}
